﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class TypeScript : MonoBehaviour
{

    public Dropdown type1Dropdown;
    public Dropdown type2Dropdown;
    public Dropdown type3Dropdown;

    public GameObject infoPanel;

    public Button confirmationButton;
    public Button quitButton;
    public Button informationButton;
    public Button okButton;

    public Text normalEffectiveness;
    public Text fightingEffectiveness;
    public Text flyingEffectiveness;
    public Text poisonEffectiveness;
    public Text groundEffectiveness;
    public Text rockEffectiveness;
    public Text bugEffectiveness;
    public Text ghostEffectiveness;
    public Text fireEffectiveness;
    public Text steelEffectiveness;
    public Text waterEffectiveness;
    public Text grassEffectiveness;
    public Text electricEffectiveness;
    public Text psychicEffectiveness;
    public Text iceEffectiveness;
    public Text dragonEffectiveness;
    public Text darkEffectiveness;
    public Text fairyEffectiveness;
    public Text lightEffectiveness;
    public Text soundEffectiveness;
    public Text crystalEffectiveness;
    public Text cosmicEffectiveness;
    public Text mysticEffectiveness;
    public Text nuclearEffectiveness;

    private string firstType;
    private string secondType;
    private string thirdType;

    private int normalCounter = 0;
    private int fightingCounter = 0;
    private int flyingCounter = 0;
    private int poisonCounter = 0;
    private int groundCounter = 0;
    private int rockCounter = 0;
    private int bugCounter = 0;
    private int ghostCounter = 0;
    private int fireCounter = 0;
    private int steelCounter = 0;
    private int waterCounter = 0;
    private int grassCounter = 0;
    private int electricCounter = 0;
    private int psychicCounter = 0;
    private int iceCounter = 0;
    private int dragonCounter = 0;
    private int darkCounter = 0;
    private int fairyCounter = 0;
    private int lightCounter = 0;
    private int soundCounter = 0;
    private int crystalCounter = 0;
    private int cosmicCounter = 0;
    private int mysticCounter = 0;
    private int nuclearCounter = 0;
    // Start is called before the first frame update
    void Start()
    {
        infoPanel.SetActive(true);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void OnConfirmButtonClick()
    {
        if(type1Dropdown.options[type1Dropdown.value].text == "None" && type2Dropdown.options[type2Dropdown.value].text == "None" && type3Dropdown.options[type3Dropdown.value].text == "None")
        {

        }
        else
        {
            normalCounter = 0;
            fightingCounter = 0;
            flyingCounter = 0;
            poisonCounter = 0;
            groundCounter = 0;
            rockCounter = 0;
            bugCounter = 0;
            ghostCounter = 0;
            fireCounter = 0;
            steelCounter = 0;
            waterCounter = 0;
            grassCounter = 0;
            electricCounter = 0;
            psychicCounter = 0;
            iceCounter = 0;
            dragonCounter = 0;
            darkCounter = 0;
            fairyCounter = 0;
            lightCounter = 0;
            soundCounter = 0;
            crystalCounter = 0;
            cosmicCounter = 0;
            mysticCounter = 0;
            nuclearCounter = 0;

            firstType = type1Dropdown.options[type1Dropdown.value].text;
            TypeChecks(firstType);
            secondType = type2Dropdown.options[type2Dropdown.value].text;
            TypeChecks(secondType);
            thirdType = type3Dropdown.options[type3Dropdown.value].text;
            TypeChecks(thirdType);

            NormalType();
            FightingType();
            FlyingType();
            PoisonType();
            GroundType();
            RockType();
            BugType();
            GhostType();
            FireType();
            SteelType();
            WaterType();
            GrassType();
            ElectricType();
            PsychicType();
            IceType();
            DragonType();
            DarkType();
            FairyType();
            LightType();
            SoundType();
            CrystalType();
            CosmicType();
            MysticType();
            NuclearType();
        }
        
        //then run a function to pass the counters into
    }

    public void OnQuitButtonClick()
    {
        Application.Quit();
    }

    public void OnOkButtonClick()
    {
        infoPanel.SetActive(false);
    }

    public void OnInfoPanelClick()
    {
        infoPanel.SetActive(true);
    }

    private void TypeChecks(string type)
    {
        if(type == "Normal")
        {
            fightingCounter++;
            ghostCounter = ghostCounter - 100;
        }
        else if(type == "Fighting")
        {
            bugCounter--;
            rockCounter--;
            flyingCounter++;
            psychicCounter++;
        }
        else if(type == "Flying")
        {
            bugCounter--;
            fightingCounter--;
            grassCounter--;
            electricCounter++;
            iceCounter++;
            rockCounter++;
            groundCounter = groundCounter - 100;
        }
        else if(type == "Poison")
        {
            fightingCounter--;
            poisonCounter--;
            grassCounter--;
            bugCounter--;
            fairyCounter--;
            groundCounter++;
            psychicCounter++;
        }
        else if(type == "Ground")
        {
            poisonCounter--;
            rockCounter--;
            grassCounter++;
            iceCounter++;
            waterCounter++;
            electricCounter = electricCounter - 100;
        }
        else if(type == "Rock")
        {
            flyingCounter--;
            fireCounter--;
            normalCounter--;
            poisonCounter--;
            fightingCounter++;
            grassCounter++;
            groundCounter++;
            steelCounter++;
            waterCounter++;
        }
        else if(type == "Bug")
        {
            fightingCounter--;
            grassCounter--;
            groundCounter--;
            fireCounter++;
            flyingCounter++;
            rockCounter++;
        }
        else if(type == "Ghost")
        {
            bugCounter--;
            poisonCounter--;
            darkCounter++;
            ghostCounter++;
            normalCounter = normalCounter - 100;
            fightingCounter = fightingCounter - 100;
        }
        else if(type == "Steel")
        {
            bugCounter--;
            darkCounter--;
            dragonCounter--;
            flyingCounter--;
            ghostCounter--;
            grassCounter--;
            iceCounter--;
            normalCounter--;
            psychicCounter--;
            rockCounter--;
            steelCounter--;
            fireCounter++;
            fightingCounter++;
            groundCounter++;
            poisonCounter = poisonCounter - 100;
        }
        else if(type == "Fire")
        {
            bugCounter--;
            fairyCounter--;
            fireCounter--;
            grassCounter--;
            iceCounter--;
            steelCounter--;
            groundCounter++;
            rockCounter++;
            waterCounter++;
        }
        else if(type == "Water")
        {
            fireCounter--;
            iceCounter--;
            steelCounter--;
            waterCounter--;
            electricCounter++;
            grassCounter++;
        }
        else if(type == "Grass")
        {
            electricCounter--;
            grassCounter--;
            groundCounter--;
            waterCounter--;
            bugCounter++;
            fireCounter++;
            flyingCounter++;
            iceCounter++;
            poisonCounter++;
        }
        else if(type == "Electric")
        {
            flyingCounter--;
            electricCounter--;
            steelCounter--;
            groundCounter++;
        }
        else if(type == "Psychic")
        {
            fightingCounter--;
            psychicCounter--;
            bugCounter++;
            darkCounter++;
            ghostCounter++;
        }
        else if(type == "Ice")
        {
            iceCounter--;
            fightingCounter++;
            fireCounter++;
            rockCounter++;
        }
        else if(type == "Dragon")
        {
            electricCounter--;
            fireCounter--;
            grassCounter--;
            waterCounter--;
            dragonCounter++;
            iceCounter++;
            fairyCounter++;
        }
        else if(type == "Dark")
        {
            darkCounter--;
            ghostCounter--;
            bugCounter++;
            fightingCounter++;
            psychicCounter = psychicCounter - 100;
        }
        else if(type == "Fairy")
        {
            bugCounter--;
            darkCounter--;
            fightingCounter--;
            poisonCounter++;
            steelCounter++;
            dragonCounter = dragonCounter - 100;
        }
        else if(type == "Light")
        {
            grassCounter++;
            poisonCounter++;
            cosmicCounter++;
            psychicCounter--;
            ghostCounter--;
            dragonCounter--;
        }
        else if(type == "Sound")
        {
            fightingCounter--;
            darkCounter--;
            mysticCounter--;
            waterCounter++;
            flyingCounter++;
            groundCounter++;
            poisonCounter++;
            cosmicCounter++;
        }
        else if(type == "Crystal")
        {

        }
        else if(type == "Cosmic")
        {
            fightingCounter--;
            iceCounter--;
            flyingCounter++;
            rockCounter++;
            poisonCounter++;
            steelCounter++;
            mysticCounter++;
            fireCounter = fireCounter - 100;
            groundCounter = groundCounter - 100;
            soundCounter = soundCounter - 100;
        }
        else if(type == "Mystic")
        {
            cosmicCounter--;
            normalCounter++;
            psychicCounter++;
            steelCounter++;
            soundCounter++;
        }
        else if(type == "Nuclear")
        {
            nuclearCounter--;
            normalCounter++;
            fightingCounter++;
            fireCounter++;
            waterCounter++;
            flyingCounter++;
            grassCounter++;
            electricCounter++;
            groundCounter++;
            psychicCounter++;
            rockCounter++;
            iceCounter++;
            bugCounter++;
            dragonCounter++;
            ghostCounter++;
            darkCounter++;
            steelCounter++;
            fairyCounter++;
            poisonCounter++;
            soundCounter++;
            cosmicCounter++;
            crystalCounter++;
            mysticCounter++;
            lightCounter++;
        }
        else
        {


        }
    }

    private void NormalType()
    {
        if(normalCounter == -3)
        {
            normalEffectiveness.text = "x1/6";
        }
        else if(normalCounter == -2)
        {
            normalEffectiveness.text = "x1/4";
        }
        else if(normalCounter == -1)
        {
            normalEffectiveness.text = "x1/2";
        }
        else if(normalCounter == 0)
        {
            normalEffectiveness.text = "x1";
        }
        else if(normalCounter == 1)
        {
            normalEffectiveness.text = "x2";
        }
        else if(normalCounter == 2)
        {
            normalEffectiveness.text = "x4";
        }
        else if(normalCounter == 3)
        {
            normalEffectiveness.text = "x6";
        }
        else
        {
            normalEffectiveness.text = "x0";
        }
    }
    private void FightingType()
    {
        if (fightingCounter == -3)
        {
            fightingEffectiveness.text = "x1/6";
        }
        else if (fightingCounter == -2)
        {
            fightingEffectiveness.text = "x1/4";
        }
        else if (fightingCounter == -1)
        {
            fightingEffectiveness.text = "x1/2";
        }
        else if (fightingCounter == 0)
        {
            fightingEffectiveness.text = "x1";
        }
        else if (fightingCounter == 1)
        {
            fightingEffectiveness.text = "x2";
        }
        else if (fightingCounter == 2)
        {
            fightingEffectiveness.text = "x4";
        }
        else if (fightingCounter == 3)
        {
            fightingEffectiveness.text = "x6";
        }
        else
        {
            fightingEffectiveness.text = "x0";
        }
    }
    private void FlyingType()
    {
        if (flyingCounter == -3)
        {
            flyingEffectiveness.text = "x1/6";
        }
        else if (flyingCounter == -2)
        {
            flyingEffectiveness.text = "x1/4";
        }
        else if (flyingCounter == -1)
        {
            flyingEffectiveness.text = "x1/2";
        }
        else if (flyingCounter == 0)
        {
            flyingEffectiveness.text = "x1";
        }
        else if (flyingCounter == 1)
        {
            flyingEffectiveness.text = "x2";
        }
        else if (flyingCounter == 2)
        {
            flyingEffectiveness.text = "x4";
        }
        else if (flyingCounter == 3)
        {
            flyingEffectiveness.text = "x6";
        }
        else
        {
            flyingEffectiveness.text = "x0";
        }
    }
    private void PoisonType()
    {
        if (poisonCounter == -3)
        {
            poisonEffectiveness.text = "x1/6";
        }
        else if (poisonCounter == -2)
        {
            poisonEffectiveness.text = "x1/4";
        }
        else if (poisonCounter == -1)
        {
            poisonEffectiveness.text = "x1/2";
        }
        else if (poisonCounter == 0)
        {
            poisonEffectiveness.text = "x1";
        }
        else if (poisonCounter == 1)
        {
            poisonEffectiveness.text = "x2";
        }
        else if (poisonCounter == 2)
        {
            poisonEffectiveness.text = "x4";
        }
        else if (poisonCounter == 3)
        {
            poisonEffectiveness.text = "x6";
        }
        else
        {
            poisonEffectiveness.text = "x0";
        }
    }
    private void GroundType()
    {
        if (groundCounter == -3)
        {
            groundEffectiveness.text = "x1/6";
        }
        else if (groundCounter == -2)
        {
            groundEffectiveness.text = "x1/4";
        }
        else if (groundCounter == -1)
        {
            groundEffectiveness.text = "x1/2";
        }
        else if (groundCounter == 0)
        {
            groundEffectiveness.text = "x1";
        }
        else if (groundCounter == 1)
        {
            groundEffectiveness.text = "x2";
        }
        else if (groundCounter == 2)
        {
            groundEffectiveness.text = "x4";
        }
        else if (groundCounter == 3)
        {
            groundEffectiveness.text = "x6";
        }
        else
        {
            groundEffectiveness.text = "x0";
        }
    }
    private void RockType()
    {
        if (rockCounter == -3)
        {
            rockEffectiveness.text = "x1/6";
        }
        else if (rockCounter == -2)
        {
            rockEffectiveness.text = "x1/4";
        }
        else if (rockCounter == -1)
        {
            rockEffectiveness.text = "x1/2";
        }
        else if (rockCounter == 0)
        {
            rockEffectiveness.text = "x1";
        }
        else if (rockCounter == 1)
        {
            rockEffectiveness.text = "x2";
        }
        else if (rockCounter == 2)
        {
            rockEffectiveness.text = "x4";
        }
        else if (rockCounter == 3)
        {
            rockEffectiveness.text = "x6";
        }
        else
        {
            rockEffectiveness.text = "x0";
        }
    }
    private void BugType()
    {
        if (bugCounter == -3)
        {
            bugEffectiveness.text = "x1/6";
        }
        else if (bugCounter == -2)
        {
            bugEffectiveness.text = "x1/4";
        }
        else if (bugCounter == -1)
        {
            bugEffectiveness.text = "x1/2";
        }
        else if (bugCounter == 0)
        {
            bugEffectiveness.text = "x1";
        }
        else if (bugCounter == 1)
        {
            bugEffectiveness.text = "x2";
        }
        else if (bugCounter == 2)
        {
            bugEffectiveness.text = "x4";
        }
        else if (bugCounter == 3)
        {
            bugEffectiveness.text = "x6";
        }
        else
        {
            bugEffectiveness.text = "x0";
        }
    }
    private void GhostType()
    {
        if (ghostCounter == -3)
        {
            ghostEffectiveness.text = "x1/6";
        }
        else if (ghostCounter == -2)
        {
            ghostEffectiveness.text = "x1/4";
        }
        else if (ghostCounter == -1)
        {
            ghostEffectiveness.text = "x1/2";
        }
        else if (ghostCounter == 0)
        {
            ghostEffectiveness.text = "x1";
        }
        else if (ghostCounter == 1)
        {
            ghostEffectiveness.text = "x2";
        }
        else if (ghostCounter == 2)
        {
            ghostEffectiveness.text = "x4";
        }
        else if (ghostCounter == 3)
        {
            ghostEffectiveness.text = "x6";
        }
        else
        {
            ghostEffectiveness.text = "x0";
        }
    }
    private void FireType()
    {
        if (fireCounter == -3)
        {
            fireEffectiveness.text = "x1/6";
        }
        else if (fireCounter == -2)
        {
            fireEffectiveness.text = "x1/4";
        }
        else if (fireCounter == -1)
        {
            fireEffectiveness.text = "x1/2";
        }
        else if (fireCounter == 0)
        {
            fireEffectiveness.text = "x1";
        }
        else if (fireCounter == 1)
        {
            fireEffectiveness.text = "x2";
        }
        else if (fireCounter == 2)
        {
            fireEffectiveness.text = "x4";
        }
        else if (fireCounter == 3)
        {
            fireEffectiveness.text = "x6";
        }
        else
        {
            fireEffectiveness.text = "x0";
        }
    }
    private void SteelType()
    {
        if (steelCounter == -3)
        {
            steelEffectiveness.text = "x1/6";
        }
        else if (steelCounter == -2)
        {
            steelEffectiveness.text = "x1/4";
        }
        else if (steelCounter == -1)
        {
            steelEffectiveness.text = "x1/2";
        }
        else if (steelCounter == 0)
        {
            steelEffectiveness.text = "x1";
        }
        else if (steelCounter == 1)
        {
            steelEffectiveness.text = "x2";
        }
        else if (steelCounter == 2)
        {
            steelEffectiveness.text = "x4";
        }
        else if (steelCounter == 3)
        {
            steelEffectiveness.text = "x6";
        }
        else
        {
            steelEffectiveness.text = "x0";
        }
    }
    private void WaterType()
    {
        if (waterCounter == -3)
        {
            waterEffectiveness.text = "x1/6";
        }
        else if (waterCounter == -2)
        {
            waterEffectiveness.text = "x1/4";
        }
        else if (waterCounter == -1)
        {
            waterEffectiveness.text = "x1/2";
        }
        else if (waterCounter == 0)
        {
            waterEffectiveness.text = "x1";
        }
        else if (waterCounter == 1)
        {
            waterEffectiveness.text = "x2";
        }
        else if (waterCounter == 2)
        {
            waterEffectiveness.text = "x4";
        }
        else if (waterCounter == 3)
        {
            waterEffectiveness.text = "x6";
        }
        else
        {
            waterEffectiveness.text = "x0";
        }
    }
    private void GrassType()
    {
        if (grassCounter == -3)
        {
            grassEffectiveness.text = "x1/6";
        }
        else if (grassCounter == -2)
        {
            grassEffectiveness.text = "x1/4";
        }
        else if (grassCounter == -1)
        {
            grassEffectiveness.text = "x1/2";
        }
        else if (grassCounter == 0)
        {
            grassEffectiveness.text = "x1";
        }
        else if (grassCounter == 1)
        {
            grassEffectiveness.text = "x2";
        }
        else if (grassCounter == 2)
        {
            grassEffectiveness.text = "x4";
        }
        else if (grassCounter == 3)
        {
            grassEffectiveness.text = "x6";
        }
        else
        {
            grassEffectiveness.text = "x0";
        }
    }
    private void ElectricType()
    {
        if (electricCounter == -3)
        {
            electricEffectiveness.text = "x1/6";
        }
        else if (electricCounter == -2)
        {
            electricEffectiveness.text = "x1/4";
        }
        else if (electricCounter == -1)
        {
            electricEffectiveness.text = "x1/2";
        }
        else if (electricCounter == 0)
        {
            electricEffectiveness.text = "x1";
        }
        else if (electricCounter == 1)
        {
            electricEffectiveness.text = "x2";
        }
        else if (electricCounter == 2)
        {
            electricEffectiveness.text = "x4";
        }
        else if (electricCounter == 3)
        {
            electricEffectiveness.text = "x6";
        }
        else
        {
            electricEffectiveness.text = "x0";
        }
    }
    private void PsychicType()
    {
        if (psychicCounter == -3)
        {
            psychicEffectiveness.text = "x1/6";
        }
        else if (psychicCounter == -2)
        {
            psychicEffectiveness.text = "x1/4";
        }
        else if (psychicCounter == -1)
        {
            psychicEffectiveness.text = "x1/2";
        }
        else if (psychicCounter == 0)
        {
            psychicEffectiveness.text = "x1";
        }
        else if (psychicCounter == 1)
        {
            psychicEffectiveness.text = "x2";
        }
        else if (psychicCounter == 2)
        {
            psychicEffectiveness.text = "x4";
        }
        else if (psychicCounter == 3)
        {
            psychicEffectiveness.text = "x6";
        }
        else
        {
            psychicEffectiveness.text = "x0";
        }
    }
    private void IceType()
    {
        if (iceCounter == -3)
        {
            iceEffectiveness.text = "x1/6";
        }
        else if (iceCounter == -2)
        {
            iceEffectiveness.text = "x1/4";
        }
        else if (iceCounter == -1)
        {
            iceEffectiveness.text = "x1/2";
        }
        else if (iceCounter == 0)
        {
            iceEffectiveness.text = "x1";
        }
        else if (iceCounter == 1)
        {
            iceEffectiveness.text = "x2";
        }
        else if (iceCounter == 2)
        {
            iceEffectiveness.text = "x4";
        }
        else if (iceCounter == 3)
        {
            iceEffectiveness.text = "x6";
        }
        else
        {
            iceEffectiveness.text = "x0";
        }
    }
    private void DragonType()
    {
        if (dragonCounter == -3)
        {
            dragonEffectiveness.text = "x1/6";
        }
        else if (dragonCounter == -2)
        {
            dragonEffectiveness.text = "x1/4";
        }
        else if (dragonCounter == -1)
        {
            dragonEffectiveness.text = "x1/2";
        }
        else if (dragonCounter == 0)
        {
            dragonEffectiveness.text = "x1";
        }
        else if (dragonCounter == 1)
        {
            dragonEffectiveness.text = "x2";
        }
        else if (dragonCounter == 2)
        {
            dragonEffectiveness.text = "x4";
        }
        else if (dragonCounter == 3)
        {
            dragonEffectiveness.text = "x6";
        }
        else
        {
            dragonEffectiveness.text = "x0";
        }
    }
    private void DarkType()
    {
        if (darkCounter == -3)
        {
            darkEffectiveness.text = "x1/6";
        }
        else if (darkCounter == -2)
        {
            darkEffectiveness.text = "x1/4";
        }
        else if (darkCounter == -1)
        {
            darkEffectiveness.text = "x1/2";
        }
        else if (darkCounter == 0)
        {
            darkEffectiveness.text = "x1";
        }
        else if (darkCounter == 1)
        {
            darkEffectiveness.text = "x2";
        }
        else if (darkCounter == 2)
        {
            darkEffectiveness.text = "x4";
        }
        else if (darkCounter == 3)
        {
            darkEffectiveness.text = "x6";
        }
        else
        {
            darkEffectiveness.text = "x0";
        }
    }
    private void FairyType()
    {
        if (fairyCounter == -3)
        {
            fairyEffectiveness.text = "x1/6";
        }
        else if (fairyCounter == -2)
        {
            fairyEffectiveness.text = "x1/4";
        }
        else if (fairyCounter == -1)
        {
            fairyEffectiveness.text = "x1/2";
        }
        else if (fairyCounter == 0)
        {
            fairyEffectiveness.text = "x1";
        }
        else if (fairyCounter == 1)
        {
            fairyEffectiveness.text = "x2";
        }
        else if (fairyCounter == 2)
        {
            fairyEffectiveness.text = "x4";
        }
        else if (fairyCounter == 3)
        {
            fairyEffectiveness.text = "x6";
        }
        else
        {
            fairyEffectiveness.text = "x0";
        }
    }
    private void LightType()
    {
        if (lightCounter == -3)
        {
            lightEffectiveness.text = "x1/6";
        }
        else if (lightCounter == -2)
        {
            lightEffectiveness.text = "x1/4";
        }
        else if (lightCounter == -1)
        {
            lightEffectiveness.text = "x1/2";
        }
        else if (lightCounter == 0)
        {
            lightEffectiveness.text = "x1";
        }
        else if (lightCounter == 1)
        {
            lightEffectiveness.text = "x2";
        }
        else if (lightCounter == 2)
        {
            lightEffectiveness.text = "x4";
        }
        else if (lightCounter == 3)
        {
            lightEffectiveness.text = "x6";
        }
        else
        {
            lightEffectiveness.text = "x0";
        }
    }
    private void SoundType()
    {
        if (soundCounter == -3)
        {
            soundEffectiveness.text = "x1/6";
        }
        else if (soundCounter == -2)
        {
            soundEffectiveness.text = "x1/4";
        }
        else if (soundCounter == -1)
        {
            soundEffectiveness.text = "x1/2";
        }
        else if (soundCounter == 0)
        {
            soundEffectiveness.text = "x1";
        }
        else if (soundCounter == 1)
        {
            soundEffectiveness.text = "x2";
        }
        else if (soundCounter == 2)
        {
            soundEffectiveness.text = "x4";
        }
        else if (soundCounter == 3)
        {
            soundEffectiveness.text = "x6";
        }
        else
        {
            soundEffectiveness.text = "x0";
        }
    }
    private void CosmicType()
    {
        if (cosmicCounter == -3)
        {
            cosmicEffectiveness.text = "x1/6";
        }
        else if (cosmicCounter == -2)
        {
            cosmicEffectiveness.text = "x1/4";
        }
        else if (cosmicCounter == -1)
        {
            cosmicEffectiveness.text = "x1/2";
        }
        else if (cosmicCounter == 0)
        {
            cosmicEffectiveness.text = "x1";
        }
        else if (cosmicCounter == 1)
        {
            cosmicEffectiveness.text = "x2";
        }
        else if (cosmicCounter == 2)
        {
            cosmicEffectiveness.text = "x4";
        }
        else if (cosmicCounter == 3)
        {
            cosmicEffectiveness.text = "x6";
        }
        else
        {
            cosmicEffectiveness.text = "x0";
        }
    }
    private void MysticType()
    {
        if (mysticCounter == -3)
        {
            mysticEffectiveness.text = "x1/6";
        }
        else if (mysticCounter == -2)
        {
            mysticEffectiveness.text = "x1/4";
        }
        else if (mysticCounter == -1)
        {
            mysticEffectiveness.text = "x1/2";
        }
        else if (mysticCounter == 0)
        {
            mysticEffectiveness.text = "x1";
        }
        else if (mysticCounter == 1)
        {
            mysticEffectiveness.text = "x2";
        }
        else if (mysticCounter == 2)
        {
            mysticEffectiveness.text = "x4";
        }
        else if (mysticCounter == 3)
        {
            mysticEffectiveness.text = "x6";
        }
        else
        {
            mysticEffectiveness.text = "x0";
        }
    }
    private void CrystalType()
    {
        if (crystalCounter == -3)
        {
            crystalEffectiveness.text = "x1/6";
        }
        else if (crystalCounter == -2)
        {
            crystalEffectiveness.text = "x1/4";
        }
        else if (crystalCounter == -1)
        {
            crystalEffectiveness.text = "x1/2";
        }
        else if (crystalCounter == 0)
        {
            crystalEffectiveness.text = "x1";
        }
        else if (crystalCounter == 1)
        {
            crystalEffectiveness.text = "x2";
        }
        else if (crystalCounter == 2)
        {
            crystalEffectiveness.text = "x4";
        }
        else if (crystalCounter == 3)
        {
            crystalEffectiveness.text = "x6";
        }
        else
        {
            crystalEffectiveness.text = "x0";
        }
    }
    private void NuclearType()
    {
        if (nuclearCounter == -3)
        {
            nuclearEffectiveness.text = "x1/6";
        }
        else if (nuclearCounter == -2)
        {
            nuclearEffectiveness.text = "x1/4";
        }
        else if (nuclearCounter == -1)
        {
            nuclearEffectiveness.text = "x1/2";
        }
        else if (nuclearCounter == 0)
        {
            nuclearEffectiveness.text = "x1";
        }
        else if (nuclearCounter == 1)
        {
            nuclearEffectiveness.text = "x2";
        }
        else if (nuclearCounter == 2)
        {
            nuclearEffectiveness.text = "x4";
        }
        else if (nuclearCounter == 3)
        {
            nuclearEffectiveness.text = "x6";
        }
        else
        {
            nuclearEffectiveness.text = "x0";
        }
    }
}
